
import java.util.Random;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */


/**
 *
 * @author zarna
 */
public class Pila {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Stack pila = new Stack();
        pila.Push(1);
        pila.Push(2);
        pila.Push(56);
        pila.Push(76);
        pila.Peek();
        pila.Pop();
        pila.Peek();
        System.out.println(pila.Size());
        
            while(pila.Size()< 5){
            Random numero = new Random();
            pila.Push(numero.nextInt());
            pila.Peek();
            System.out.println(pila.Size());
            }
    }
    
}
