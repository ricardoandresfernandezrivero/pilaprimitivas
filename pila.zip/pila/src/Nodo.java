/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author zarna
 * @param <T>
 */
public class Nodo<T> {
    int data;
    Nodo pNext;

    public Nodo(int data, Nodo pNext) {
        this.data = data;
        this.pNext = pNext;
    }
    public Nodo(int data) {
        this.data = data;
        this.pNext = null;
    }
    
    
    
}
