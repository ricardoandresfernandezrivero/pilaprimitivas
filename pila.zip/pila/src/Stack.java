/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


public class Stack {
    Nodo top;
    int iN;

    /**
     *
     */
    public Stack() {
        this.top = null;
        this.iN = 0;
    }
    
    public boolean isEmpty(){
        assert(this.top==null && iN==0);
        return iN == 0;
    }
    
    public void Empty(){
        this.top=null;
        iN=0;
    }
    
    public void Push(int data){
    Nodo pNew = new Nodo(data);
    pNew.pNext = this.top;
    this.top = pNew;
    iN++;
    }
    
    public void Peek(){
    System.out.println(this.top.data);
    }
    
    public void Pop(){
    Nodo pTemp = this.top;
    this.top = this.top.pNext;
    pTemp = null;
    iN--;
    }
    
    public int Size(){
        return iN;
    }
    
}
